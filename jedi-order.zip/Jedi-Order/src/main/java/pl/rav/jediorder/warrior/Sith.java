package pl.rav.jediorder.warrior;

public class Sith extends Warrior{
}

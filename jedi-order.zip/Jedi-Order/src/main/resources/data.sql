DELETE FROM jedi;

INSERT INTO jedi (created, name, side, lightsaber, strength, appearance, jOrder)
VALUES ('2020-04-24', 'Tim', 'Light Side', 'Red', 100, 'MasterYoda01','Defenders');